import axios from "axios";

export const api = axios.create({
  baseURL: "https://6acfdff3-d03c-4661-9633-68037d93ae64-00-12sv7mrryoumn.sisko.replit.dev/api"
});